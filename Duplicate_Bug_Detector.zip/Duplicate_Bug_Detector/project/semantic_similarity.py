import pandas as pd
from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity

# Load dataset
data = pd.read_csv("../data/bug_reports.csv")
data.columns = data.columns.str.strip()

# Load Sentence-BERT model
print("Loading Sentence-BERT model...")
model = SentenceTransformer("all-MiniLM-L6-v2")

# Get existing bug descriptions
bug_descriptions = data["Bug_Description"].astype(str).tolist()

# Convert existing bug descriptions into embeddings
print("Creating embeddings...")
bug_embeddings = model.encode(bug_descriptions)

# Get new bug report
new_bug = input("\nEnter your new bug report: ")

# Convert new bug into embedding
new_bug_embedding = model.encode([new_bug])

# Calculate semantic similarity
similarities = cosine_similarity(
    new_bug_embedding,
    bug_embeddings
)[0]

# Find best matching bug
best_index = similarities.argmax()
best_score = similarities[best_index]

# Get bug details
best_bug_id = data.iloc[best_index, 0]
best_description = data.iloc[best_index]["Bug_Description"]
best_category = data.iloc[best_index]["Category"]
best_status = data.iloc[best_index]["Status"]

# Display result
print("\n" + "=" * 65)
print("          SEMANTIC DUPLICATE BUG DETECTOR")
print("=" * 65)

print("\nNew Bug:")
print(new_bug)

print("\nBest Matching Bug:")
print(f"Bug ID     : {best_bug_id}")
print(f"Description: {best_description}")
print(f"Category   : {best_category}")
print(f"Status     : {best_status}")
print(f"Similarity : {best_score * 100:.2f}%")

# Threshold
threshold = 60

if best_score * 100 >= threshold:
    print("\n⚠️ POSSIBLE DUPLICATE BUG")
else:
    print("\n✅ NEW BUG")

print("=" * 65)