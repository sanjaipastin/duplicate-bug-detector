import pandas as pd
import nltk
import re

# Download required NLTK data
nltk.download("stopwords", quiet=True)
nltk.download("wordnet", quiet=True)

from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer

# Load dataset
data = pd.read_csv("../data/bug_reports.csv")

# Show the column names from CSV
print("CSV Columns:")
print(data.columns.tolist())

# NLP tools
stop_words = set(stopwords.words("english"))
lemmatizer = WordNetLemmatizer()


def preprocess_text(text):
    # Convert to lowercase
    text = str(text).lower()

    # Remove special characters and numbers
    text = re.sub(r"[^a-zA-Z\s]", "", text)

    # Split into words
    words = text.split()

    # Remove stopwords and lemmatize
    words = [
        lemmatizer.lemmatize(word)
        for word in words
        if word not in stop_words
    ]

    return " ".join(words)


# Apply preprocessing
data["Cleaned_Description"] = data["Bug_Description"].apply(preprocess_text)

# Display first 15 processed records
print("\nProcessed Bug Reports:")
print(
    data[
        ["Bug_Description", "Cleaned_Description"]
    ].head(15).to_string(index=False)
)