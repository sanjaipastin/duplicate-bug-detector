import pandas as pd
from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    confusion_matrix
)

# -------------------------------------------------
# Load 60-bug dataset
# -------------------------------------------------

data = pd.read_csv("../data/bug_reports.csv")
data.columns = data.columns.str.strip()

# -------------------------------------------------
# Create evaluation pairs
# -------------------------------------------------

pairs = []

for i in range(len(data)):

    for j in range(i + 1, len(data)):

        bug1 = data.iloc[i]
        bug2 = data.iloc[j]

        # Same category = related/duplicate candidate
        if bug1["Category"] == bug2["Category"]:

            pairs.append({
                "Bug_1": bug1["Bug_Description"],
                "Bug_2": bug2["Bug_Description"],
                "Actual": 1
            })

        # Different category = non-duplicate
        else:

            pairs.append({
                "Bug_1": bug1["Bug_Description"],
                "Bug_2": bug2["Bug_Description"],
                "Actual": 0
            })

# Limit evaluation size for faster testing
pairs_df = pd.DataFrame(pairs)

# Use balanced sample
duplicate_pairs = pairs_df[pairs_df["Actual"] == 1].head(100)
non_duplicate_pairs = pairs_df[pairs_df["Actual"] == 0].head(100)

evaluation_data = pd.concat(
    [duplicate_pairs, non_duplicate_pairs],
    ignore_index=True
)

print("=" * 60)
print("FINAL BUG DETECTION EVALUATION")
print("=" * 60)

print(f"\nTotal Evaluation Pairs: {len(evaluation_data)}")
print(f"Duplicate Pairs: {sum(evaluation_data['Actual'] == 1)}")
print(f"Non-Duplicate Pairs: {sum(evaluation_data['Actual'] == 0)}")

# -------------------------------------------------
# Load Sentence-BERT
# -------------------------------------------------

print("\nLoading Sentence-BERT model...")

model = SentenceTransformer("all-MiniLM-L6-v2")

# -------------------------------------------------
# Generate embeddings
# -------------------------------------------------

print("Creating embeddings...")

bug1_embeddings = model.encode(
    evaluation_data["Bug_1"].tolist()
)

bug2_embeddings = model.encode(
    evaluation_data["Bug_2"].tolist()
)

# -------------------------------------------------
# Calculate semantic similarity
# -------------------------------------------------

similarities = []

for i in range(len(evaluation_data)):

    score = cosine_similarity(
        [bug1_embeddings[i]],
        [bug2_embeddings[i]]
    )[0][0]

    score = max(0, min(1, score))

    similarities.append(score * 100)

evaluation_data["Similarity"] = similarities

# -------------------------------------------------
# Threshold
# -------------------------------------------------

threshold = 60

evaluation_data["Predicted"] = (
    evaluation_data["Similarity"] >= threshold
).astype(int)

# -------------------------------------------------
# Metrics
# -------------------------------------------------

actual = evaluation_data["Actual"]
predicted = evaluation_data["Predicted"]

accuracy = accuracy_score(actual, predicted)
precision = precision_score(
    actual,
    predicted,
    zero_division=0
)
recall = recall_score(
    actual,
    predicted,
    zero_division=0
)
f1 = f1_score(
    actual,
    predicted,
    zero_division=0
)

cm = confusion_matrix(actual, predicted)

# -------------------------------------------------
# Results
# -------------------------------------------------

print("\n" + "-" * 60)

print(f"Accuracy  : {accuracy * 100:.2f}%")
print(f"Precision : {precision * 100:.2f}%")
print(f"Recall    : {recall * 100:.2f}%")
print(f"F1-Score  : {f1 * 100:.2f}%")

print("\nConfusion Matrix:")
print(cm)

print("\n" + "=" * 60)