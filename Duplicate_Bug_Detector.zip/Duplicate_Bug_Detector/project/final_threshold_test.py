import pandas as pd
from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score
)

# -------------------------------------------------
# Recreate the same evaluation pairs
# -------------------------------------------------

data = pd.read_csv("../data/bug_reports.csv")
data.columns = data.columns.str.strip()

pairs = []

for i in range(len(data)):

    for j in range(i + 1, len(data)):

        bug1 = data.iloc[i]
        bug2 = data.iloc[j]

        if bug1["Category"] == bug2["Category"]:

            pairs.append({
                "Bug_1": bug1["Bug_Description"],
                "Bug_2": bug2["Bug_Description"],
                "Actual": 1
            })

        else:

            pairs.append({
                "Bug_1": bug1["Bug_Description"],
                "Bug_2": bug2["Bug_Description"],
                "Actual": 0
            })

pairs_df = pd.DataFrame(pairs)

# -------------------------------------------------
# Balanced evaluation set
# -------------------------------------------------

duplicate_pairs = pairs_df[pairs_df["Actual"] == 1].head(100)
non_duplicate_pairs = pairs_df[pairs_df["Actual"] == 0].head(100)

evaluation_data = pd.concat(
    [duplicate_pairs, non_duplicate_pairs],
    ignore_index=True
)

print("=" * 70)
print("       FINAL THRESHOLD OPTIMIZATION")
print("=" * 70)

print(f"\nEvaluation pairs: {len(evaluation_data)}")
print(f"Duplicate pairs: {sum(evaluation_data['Actual'] == 1)}")
print(f"Non-duplicate pairs: {sum(evaluation_data['Actual'] == 0)}")

# -------------------------------------------------
# Load model
# -------------------------------------------------

print("\nLoading Sentence-BERT...")

model = SentenceTransformer("all-MiniLM-L6-v2")

# -------------------------------------------------
# Create embeddings
# -------------------------------------------------

print("Creating embeddings...")

bug1_embeddings = model.encode(
    evaluation_data["Bug_1"].tolist()
)

bug2_embeddings = model.encode(
    evaluation_data["Bug_2"].tolist()
)

# -------------------------------------------------
# Calculate similarity
# -------------------------------------------------

similarity_scores = []

for i in range(len(evaluation_data)):

    score = cosine_similarity(
        [bug1_embeddings[i]],
        [bug2_embeddings[i]]
    )[0][0]

    # Convert to percentage
    score = score * 100

    # Keep in 0-100 range
    score = max(0, min(100, score))

    similarity_scores.append(score)

evaluation_data["Similarity"] = similarity_scores

actual = evaluation_data["Actual"]

# -------------------------------------------------
# Thresholds to test
# -------------------------------------------------

thresholds = [40, 45, 50, 55, 60, 65, 70]

results = []

print("\n" + "-" * 70)
print("THRESHOLD RESULTS")
print("-" * 70)

for threshold in thresholds:

    predicted = (
        evaluation_data["Similarity"] >= threshold
    ).astype(int)

    accuracy = accuracy_score(
        actual,
        predicted
    )

    precision = precision_score(
        actual,
        predicted,
        zero_division=0
    )

    recall = recall_score(
        actual,
        predicted,
        zero_division=0
    )

    f1 = f1_score(
        actual,
        predicted,
        zero_division=0
    )

    results.append({
        "Threshold": threshold,
        "Accuracy": accuracy,
        "Precision": precision,
        "Recall": recall,
        "F1": f1
    })

    print(f"\nThreshold : {threshold}%")
    print(f"Accuracy  : {accuracy * 100:.2f}%")
    print(f"Precision : {precision * 100:.2f}%")
    print(f"Recall    : {recall * 100:.2f}%")
    print(f"F1-Score  : {f1 * 100:.2f}%")

# -------------------------------------------------
# Find best threshold using F1
# -------------------------------------------------

best = max(
    results,
    key=lambda x: x["F1"]
)

print("\n" + "=" * 70)
print("                 RECOMMENDED THRESHOLD")
print("=" * 70)

print(
    f"\nThreshold : {best['Threshold']}%"
)

print(
    f"Accuracy  : {best['Accuracy'] * 100:.2f}%"
)

print(
    f"Precision : {best['Precision'] * 100:.2f}%"
)

print(
    f"Recall    : {best['Recall'] * 100:.2f}%"
)

print(
    f"F1-Score  : {best['F1'] * 100:.2f}%"
)

print("=" * 70)