import pandas as pd

bugs = [

    # Authentication
    ("B001", "Login page crashes when wrong password is entered", "Authentication", "Open"),
    ("B002", "Password reset link is not received by user", "Authentication", "Open"),
    ("B003", "User account gets locked after a failed login attempt", "Authentication", "Open"),
    ("B004", "Application closes when invalid password is entered", "Authentication", "Open"),
    ("B005", "Login screen freezes after entering username", "Authentication", "Open"),
    ("B006", "User cannot log in after resetting the password", "Authentication", "Fixed"),

    # Performance
    ("B007", "Dashboard takes too long to load", "Performance", "Open"),
    ("B008", "Dashboard loading is very slow", "Performance", "Open"),
    ("B009", "Application becomes slow when many users are connected", "Performance", "Open"),
    ("B010", "Search results take several seconds to appear", "Performance", "Open"),
    ("B011", "Application freezes while opening the dashboard", "Performance", "Open"),
    ("B012", "Reports take a long time to generate", "Performance", "Open"),

    # Payment
    ("B013", "Payment fails after OTP verification", "Payment", "Fixed"),
    ("B014", "UPI payment does not work after OTP", "Payment", "Fixed"),
    ("B015", "Credit card payment fails during checkout", "Payment", "Open"),
    ("B016", "Payment gets stuck after entering OTP", "Payment", "Open"),
    ("B017", "Transaction amount is deducted but order remains unpaid", "Payment", "Open"),
    ("B018", "Refund is not credited to the customer account", "Payment", "Open"),

    # File Upload
    ("B019", "User cannot upload profile image", "File Upload", "Open"),
    ("B020", "Profile picture upload is not working", "File Upload", "Open"),
    ("B021", "Large PDF file cannot be uploaded", "File Upload", "Open"),
    ("B022", "Image upload fails for PNG files", "File Upload", "Open"),
    ("B023", "Uploaded document disappears after page refresh", "File Upload", "Open"),
    ("B024", "File upload shows an unknown error", "File Upload", "Open"),

    # UI
    ("B025", "Submit button is not visible on the registration page", "UI", "Open"),
    ("B026", "Dropdown menu does not open when clicked", "UI", "Open"),
    ("B027", "Text overlaps with icons on the mobile screen", "UI", "Open"),
    ("B028", "Close button does not respond to clicks", "UI", "Open"),
    ("B029", "Page layout breaks on smaller screen sizes", "UI", "Open"),
    ("B030", "Error message is displayed outside the form", "UI", "Open"),

    # Database
    ("B031", "Customer records are not saved in the database", "Database", "Open"),
    ("B032", "Duplicate records are created after submitting the form", "Database", "Open"),
    ("B033", "Old customer information is displayed after an update", "Database", "Open"),
    ("B034", "Database connection fails during application startup", "Database", "Open"),
    ("B035", "Deleted records still appear in the search results", "Database", "Open"),
    ("B036", "Database query returns incomplete customer information", "Database", "Open"),

    # Network
    ("B037", "Application disconnects from the server frequently", "Network", "Open"),
    ("B038", "API request fails when the internet connection is unstable", "Network", "Open"),
    ("B039", "Server response is lost during data submission", "Network", "Open"),
    ("B040", "The application cannot connect to the backend server", "Network", "Open"),
    ("B041", "Network timeout occurs while loading user data", "Network", "Open"),
    ("B042", "API connection drops while downloading files", "Network", "Open"),

    # Security
    ("B043", "User can access another user's profile without permission", "Security", "Open"),
    ("B044", "Password is visible in the browser URL", "Security", "Open"),
    ("B045", "Session remains active after the user logs out", "Security", "Open"),
    ("B046", "Unauthorized user can access the admin dashboard", "Security", "Open"),
    ("B047", "Sensitive customer information is displayed in error logs", "Security", "Open"),
    ("B048", "Application accepts weak passwords during registration", "Security", "Open"),

    # Search
    ("B049", "Search does not return results for valid customer names", "Search", "Open"),
    ("B050", "Search returns unrelated products for a keyword", "Search", "Open"),
    ("B051", "Search stops working after applying a filter", "Search", "Open"),
    ("B052", "Search results are not sorted correctly", "Search", "Open"),
    ("B053", "Search cannot find products with special characters", "Search", "Open"),
    ("B054", "Search field clears automatically after submitting a query", "Search", "Open"),

    # Notification
    ("B055", "User does not receive email notification after registration", "Notification", "Open"),
    ("B056", "Password reset notification is not sent", "Notification", "Open"),
    ("B057", "Push notifications are delayed by several minutes", "Notification", "Open"),
    ("B058", "Notification shows the wrong order status", "Notification", "Open"),
    ("B059", "User receives duplicate notifications for one transaction", "Notification", "Open"),
    ("B060", "Email notification contains incorrect customer details", "Notification", "Open"),
]

# Create dataframe
df = pd.DataFrame(
    bugs,
    columns=["Bug_ID", "Bug_Description", "Category", "Status"]
)

# Save dataset
df.to_csv("../data/bug_reports.csv", index=False)

print("=" * 60)
print("BUG DATASET CREATED SUCCESSFULLY")
print("=" * 60)

print(f"\nTotal Bug Reports: {len(df)}")
print("\nCategories:")
print(df["Category"].value_counts())

print("\nDataset saved to:")
print("../data/bug_reports.csv")