import pandas as pd
from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.metrics import (
    precision_score,
    recall_score,
    f1_score,
    confusion_matrix,
    classification_report
)

# -------------------------------------------------
# Load evaluation dataset
# -------------------------------------------------

data = pd.read_csv("../data/evaluation_pairs.csv")

# -------------------------------------------------
# Load Sentence-BERT model
# -------------------------------------------------

print("Loading Sentence-BERT model...")

model = SentenceTransformer("all-MiniLM-L6-v2")

# -------------------------------------------------
# Create embeddings
# -------------------------------------------------

print("Creating embeddings...")

bug1_embeddings = model.encode(
    data["Bug_1"].astype(str).tolist()
)

bug2_embeddings = model.encode(
    data["Bug_2"].astype(str).tolist()
)

# -------------------------------------------------
# Calculate similarity
# -------------------------------------------------

similarity_scores = []

for i in range(len(data)):

    score = cosine_similarity(
        [bug1_embeddings[i]],
        [bug2_embeddings[i]]
    )[0][0]

    similarity_scores.append(score * 100)

data["Similarity"] = similarity_scores

# -------------------------------------------------
# Prediction
# -------------------------------------------------

threshold = 60

data["Predicted"] = (
    data["Similarity"] >= threshold
).astype(int)

# -------------------------------------------------
# Actual values
# -------------------------------------------------

actual = data["Actual"]
predicted = data["Predicted"]

# -------------------------------------------------
# Metrics
# -------------------------------------------------

precision = precision_score(
    actual,
    predicted,
    zero_division=0
)

recall = recall_score(
    actual,
    predicted,
    zero_division=0
)

f1 = f1_score(
    actual,
    predicted,
    zero_division=0
)

cm = confusion_matrix(actual, predicted)

# -------------------------------------------------
# Display results
# -------------------------------------------------

print("\n" + "=" * 60)
print("       DUPLICATE BUG DETECTION EVALUATION")
print("=" * 60)

print("\nPair-wise Results:\n")

for i in range(len(data)):

    result = (
        "Duplicate"
        if data.iloc[i]["Predicted"] == 1
        else "Not Duplicate"
    )

    print(
        f"{i + 1}. "
        f"Similarity: {data.iloc[i]['Similarity']:.2f}% "
        f"| Actual: {data.iloc[i]['Actual']} "
        f"| Predicted: {result}"
    )

print("\n" + "-" * 60)

print(f"Precision : {precision * 100:.2f}%")
print(f"Recall    : {recall * 100:.2f}%")
print(f"F1-Score  : {f1 * 100:.2f}%")

print("\nConfusion Matrix:")
print(cm)

print("\nClassification Report:")
print(
    classification_report(
        actual,
        predicted,
        target_names=["Not Duplicate", "Duplicate"],
        zero_division=0
    )
)

print("=" * 60)