import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# Load dataset
data = pd.read_csv("../data/bug_reports.csv")

# Remove extra spaces from column names
data.columns = data.columns.str.strip()

print("Columns found:")
print(data.columns.tolist())

# Get bug descriptions
texts = data["Bug_Description"].astype(str)

# TF-IDF
vectorizer = TfidfVectorizer(stop_words="english")
tfidf_matrix = vectorizer.fit_transform(texts)

print("\nTF-IDF created successfully!")

# Cosine Similarity
similarity_matrix = cosine_similarity(tfidf_matrix)

print("Cosine similarity calculated successfully!")
print("\nSimilarity Results:\n")

# Compare first 5 bugs
for i in range(min(5, len(data))):
    for j in range(i + 1, min(5, len(data))):

        score = similarity_matrix[i][j]

        # Get values by position
        bug1_id = data.iloc[i, 0]
        bug2_id = data.iloc[j, 0]

        print(
            f"{bug1_id} vs {bug2_id} = "
            f"{score * 100:.2f}%"
        )