import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# Load existing bug reports
data = pd.read_csv("../data/bug_reports.csv")
data.columns = data.columns.str.strip()

# Get existing bug descriptions
existing_bugs = data["Bug_Description"].astype(str)

# Create TF-IDF vectors
vectorizer = TfidfVectorizer(stop_words="english")
tfidf_matrix = vectorizer.fit_transform(existing_bugs)

# Get new bug from user
new_bug = input("\nEnter your new bug report: ")

# Convert new bug into TF-IDF vector
new_bug_vector = vectorizer.transform([new_bug])

# Compare new bug with all existing bugs
similarities = cosine_similarity(new_bug_vector, tfidf_matrix)[0]

# Find highest similarity
best_index = similarities.argmax()
best_score = similarities[best_index]

# Get matching bug details
best_bug_id = data.iloc[best_index, 0]
best_description = data.iloc[best_index]["Bug_Description"]
best_category = data.iloc[best_index]["Category"]
best_status = data.iloc[best_index]["Status"]

print("\n" + "=" * 60)
print("             DUPLICATE BUG DETECTOR")
print("=" * 60)

print(f"\nNew Bug:")
print(new_bug)

print(f"\nBest Matching Bug: {best_bug_id}")
print(f"Existing Bug: {best_description}")
print(f"Category: {best_category}")
print(f"Status: {best_status}")
print(f"Similarity: {best_score * 100:.2f}%")

# Duplicate threshold
threshold = 50

if best_score * 100 >= threshold:
    print("\n⚠️ POSSIBLE DUPLICATE BUG")
else:
    print("\n✅ NEW BUG - No highly similar bug found")

print("=" * 60)