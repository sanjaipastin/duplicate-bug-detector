import pandas as pd
from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.metrics import precision_score, recall_score, f1_score, accuracy_score

# -------------------------------------------------
# Load evaluation dataset
# -------------------------------------------------

data = pd.read_csv("../data/evaluation_pairs.csv")

# -------------------------------------------------
# Load Sentence-BERT model
# -------------------------------------------------

print("Loading Sentence-BERT model...")

model = SentenceTransformer("all-MiniLM-L6-v2")

# -------------------------------------------------
# Create embeddings
# -------------------------------------------------

print("Creating embeddings...")

bug1_embeddings = model.encode(
    data["Bug_1"].astype(str).tolist()
)

bug2_embeddings = model.encode(
    data["Bug_2"].astype(str).tolist()
)

# -------------------------------------------------
# Calculate similarity scores
# -------------------------------------------------

similarity_scores = []

for i in range(len(data)):

    score = cosine_similarity(
        [bug1_embeddings[i]],
        [bug2_embeddings[i]]
    )[0][0]

    # Convert similarity to percentage
    score = score * 100

    # Keep within 0-100 for display
    score = max(0, min(100, score))

    similarity_scores.append(score)

data["Similarity"] = similarity_scores

actual = data["Actual"]

# -------------------------------------------------
# Test different thresholds
# -------------------------------------------------

thresholds = [40, 50, 60, 70, 80]

results = []

print("\n" + "=" * 75)
print("                 THRESHOLD COMPARISON")
print("=" * 75)

for threshold in thresholds:

    predicted = (
        data["Similarity"] >= threshold
    ).astype(int)

    accuracy = accuracy_score(actual, predicted)
    precision = precision_score(
        actual,
        predicted,
        zero_division=0
    )
    recall = recall_score(
        actual,
        predicted,
        zero_division=0
    )
    f1 = f1_score(
        actual,
        predicted,
        zero_division=0
    )

    results.append({
        "Threshold": threshold,
        "Accuracy": accuracy * 100,
        "Precision": precision * 100,
        "Recall": recall * 100,
        "F1": f1 * 100
    })

    print(
        f"\nThreshold: {threshold}%"
    )
    print(
        f"Accuracy : {accuracy * 100:.2f}%"
    )
    print(
        f"Precision: {precision * 100:.2f}%"
    )
    print(
        f"Recall   : {recall * 100:.2f}%"
    )
    print(
        f"F1-Score : {f1 * 100:.2f}%"
    )

# -------------------------------------------------
# Find best threshold based on F1-score
# -------------------------------------------------

best_result = max(
    results,
    key=lambda x: x["F1"]
)

print("\n" + "=" * 75)
print("                    BEST THRESHOLD")
print("=" * 75)

print(
    f"\nBest Threshold : {best_result['Threshold']}%"
)

print(
    f"Accuracy       : {best_result['Accuracy']:.2f}%"
)

print(
    f"Precision      : {best_result['Precision']:.2f}%"
)

print(
    f"Recall         : {best_result['Recall']:.2f}%"
)

print(
    f"F1-Score       : {best_result['F1']:.2f}%"
)

print("=" * 75)