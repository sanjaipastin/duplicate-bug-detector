import streamlit as st
import pandas as pd
from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity

# -------------------------------------------------
# PAGE CONFIGURATION
# -------------------------------------------------

st.set_page_config(
    page_title="Duplicate Bug Detector",
    page_icon="🐞",
    layout="wide"
)

# -------------------------------------------------
# CSS
# -------------------------------------------------

st.markdown("""
<style>
.title {
    text-align: center;
    font-size: 38px;
    font-weight: bold;
}

.subtitle {
    text-align: center;
    color: #666;
    font-size: 17px;
    margin-bottom: 30px;
}

.bug-card {
    padding: 18px;
    border: 1px solid #dddddd;
    border-radius: 12px;
    margin-bottom: 12px;
}
</style>
""", unsafe_allow_html=True)

# -------------------------------------------------
# TITLE
# -------------------------------------------------

st.markdown(
    '<div class="title">🐞 Duplicate Software Bug Detector</div>',
    unsafe_allow_html=True
)

st.markdown(
    '<div class="subtitle">'
    'NLP-Based Semantic Duplicate Bug Report Detection System'
    '</div>',
    unsafe_allow_html=True
)

# -------------------------------------------------
# THRESHOLDS
# -------------------------------------------------

HIGH_THRESHOLD = 70.0
POSSIBLE_THRESHOLD = 40.0

# -------------------------------------------------
# LOAD MODEL
# -------------------------------------------------

@st.cache_resource
def load_model():
    return SentenceTransformer("all-MiniLM-L6-v2")


model = load_model()

# -------------------------------------------------
# LOAD DATA
# -------------------------------------------------

def load_data():
    data = pd.read_csv("../data/bug_reports.csv")
    data.columns = data.columns.str.strip()
    return data


# Store data in session state
if "data" not in st.session_state:
    st.session_state.data = load_data()

data = st.session_state.data

# -------------------------------------------------
# CREATE / UPDATE EMBEDDINGS
# -------------------------------------------------

def create_embeddings(df):
    descriptions = (
        df["Bug_Description"]
        .astype(str)
        .tolist()
    )

    return model.encode(descriptions)


if "bug_embeddings" not in st.session_state:
    st.session_state.bug_embeddings = create_embeddings(data)

bug_embeddings = st.session_state.bug_embeddings

# -------------------------------------------------
# SIDEBAR
# -------------------------------------------------

with st.sidebar:

    st.header("📊 Project Information")

    st.write("**NLP Model:** Sentence-BERT")
    st.write("**Similarity:** Cosine Similarity")
    st.write(f"**Bug Reports:** {len(data)}")

    st.divider()

    st.subheader("🎯 Decision Levels")

    st.write("🔴 **70% and above**")
    st.caption("High-Confidence Duplicate")

    st.write("🟡 **40% – 69.99%**")
    st.caption("Possible Duplicate")

    st.write("🟢 **Below 40%**")
    st.caption("New Bug")

    st.divider()

    st.subheader("📂 Categories")

    category_counts = data["Category"].value_counts()

    for category, count in category_counts.items():
        st.write(f"• {category}: {count}")

# -------------------------------------------------
# INPUT
# -------------------------------------------------

st.subheader("📝 Enter New Bug Report")

new_bug = st.text_area(
    "Bug Description",
    height=150,
    placeholder=(
        "Example:\n"
        "The application closes when I enter an incorrect password."
    )
)

category = st.selectbox(
    "Bug Category",
    [
        "Authentication",
        "Performance",
        "Payment",
        "File Upload",
        "UI",
        "Database",
        "Network",
        "Security",
        "Search",
        "Notification",
        "Other"
    ]
)

status = st.selectbox(
    "Bug Status",
    [
        "Open",
        "In Progress",
        "Fixed"
    ]
)

check_button = st.button(
    "🔍 CHECK BUG",
    use_container_width=True
)

# -------------------------------------------------
# DETECTION
# -------------------------------------------------

if check_button:

    if not new_bug.strip():

        st.warning("Please enter a bug description.")

    else:

        # New bug embedding
        new_bug_embedding = model.encode([new_bug])

        # Similarity
        similarities = cosine_similarity(
            new_bug_embedding,
            bug_embeddings
        )[0]

        # Convert to percentage
        similarities_percent = [
            max(0.0, min(100.0, score * 100))
            for score in similarities
        ]

        # Top 3
        top_indices = sorted(
            range(len(similarities_percent)),
            key=lambda i: similarities_percent[i],
            reverse=True
        )[:3]

        best_index = top_indices[0]
        best_score = similarities_percent[best_index]

        best_bug_id = data.iloc[best_index, 0]
        best_category = data.iloc[best_index]["Category"]
        best_status = data.iloc[best_index]["Status"]
        best_description = data.iloc[best_index]["Bug_Description"]

        st.session_state.last_result = {
            "new_bug": new_bug,
            "category": category,
            "status": status,
            "best_score": best_score,
            "best_index": best_index,
            "top_indices": top_indices,
            "similarities_percent": similarities_percent
        }

# -------------------------------------------------
# SHOW RESULT
# -------------------------------------------------

if "last_result" in st.session_state:

    result = st.session_state.last_result

    new_bug = result["new_bug"]
    category = result["category"]
    status = result["status"]
    best_score = result["best_score"]
    best_index = result["best_index"]
    top_indices = result["top_indices"]
    similarities_percent = result["similarities_percent"]

    best_bug_id = data.iloc[best_index, 0]
    best_category = data.iloc[best_index]["Category"]
    best_status = data.iloc[best_index]["Status"]
    best_description = data.iloc[best_index]["Bug_Description"]

    st.divider()

    # -------------------------------------------------
    # CLASSIFICATION
    # -------------------------------------------------

    if best_score >= HIGH_THRESHOLD:

        st.error("🔴 HIGH-CONFIDENCE DUPLICATE")

        st.write(
            "The new bug is highly similar to an existing bug."
        )

        duplicate_found = True

    elif best_score >= POSSIBLE_THRESHOLD:

        st.warning("🟡 POSSIBLE DUPLICATE")

        st.write(
            "A similar bug was found. Manual review is recommended."
        )

        duplicate_found = True

    else:

        st.success("🟢 NEW BUG")

        st.write(
            "No sufficiently similar bug was found."
        )

        duplicate_found = False

    # -------------------------------------------------
    # METRICS
    # -------------------------------------------------

    col1, col2, col3 = st.columns(3)

    with col1:
        st.metric(
            "Highest Similarity",
            f"{best_score:.2f}%"
        )

    with col2:
        st.metric(
            "Matching Bug",
            best_bug_id
        )

    with col3:
        st.metric(
            "Category",
            best_category
        )

    # -------------------------------------------------
    # BEST MATCH
    # -------------------------------------------------

    st.subheader("🎯 Best Matching Bug")

    st.markdown(
        f"""
        <div class="bug-card">

        <b>Bug ID:</b> {best_bug_id}<br><br>

        <b>Description:</b><br>
        {best_description}<br><br>

        <b>Category:</b> {best_category}<br>

        <b>Status:</b> {best_status}<br>

        <b>Similarity:</b> {best_score:.2f}%

        </div>
        """,
        unsafe_allow_html=True
    )

    # -------------------------------------------------
    # TOP 3
    # -------------------------------------------------

    st.subheader("🔎 Top 3 Similar Bugs")

    for rank, index in enumerate(
        top_indices,
        start=1
    ):

        bug_id = data.iloc[index, 0]
        description = data.iloc[index]["Bug_Description"]
        bug_category = data.iloc[index]["Category"]
        bug_status = data.iloc[index]["Status"]
        score = similarities_percent[index]

        st.markdown(
            f"""
            <div class="bug-card">

            <h4>{rank}. {bug_id}</h4>

            <b>Similarity:</b> {score:.2f}%<br><br>

            <b>Description:</b><br>
            {description}<br><br>

            <b>Category:</b> {bug_category}<br>

            <b>Status:</b> {bug_status}

            </div>
            """,
            unsafe_allow_html=True
        )

    # -------------------------------------------------
    # ADD NEW BUG
    # -------------------------------------------------

    if not duplicate_found:

        st.divider()

        st.subheader("➕ Add New Bug")

        st.write(
            "No sufficiently similar bug was found. "
            "You can add this report to the database."
        )

        if st.button(
            "➕ ADD THIS BUG TO DATABASE",
            use_container_width=True
        ):

            # Find next Bug ID
            bug_numbers = []

            for bug_id in data.iloc[:, 0]:

                try:
                    number = int(
                        str(bug_id).replace("B", "")
                    )
                    bug_numbers.append(number)

                except ValueError:
                    pass

            next_id = (
                max(bug_numbers) + 1
                if bug_numbers
                else 1
            )

            new_bug_id = f"B{next_id:03d}"

            # Create new record
            new_record = pd.DataFrame([
                {
                    "Bug_ID": new_bug_id,
                    "Bug_Description": new_bug,
                    "Category": category,
                    "Status": status
                }
            ])

            # Update dataframe
            updated_data = pd.concat(
                [data, new_record],
                ignore_index=True
            )

            # Save CSV
            updated_data.to_csv(
                "../data/bug_reports.csv",
                index=False
            )

            # Update session state
            st.session_state.data = updated_data

            # Re-create embeddings immediately
            st.session_state.bug_embeddings = (
                create_embeddings(updated_data)
            )

            # Update local references
            data = updated_data
            bug_embeddings = st.session_state.bug_embeddings

            # Clear old result
            if "last_result" in st.session_state:
                del st.session_state["last_result"]

            st.success(
                f"✅ {new_bug_id} successfully added to the database!"
            )

            st.rerun()

# -------------------------------------------------
# FOOTER
# -------------------------------------------------

st.divider()

st.caption(
    "NLP-Based Duplicate Software Bug Report Detection System | "
    "Python • Sentence-BERT • Cosine Similarity • Streamlit"
)